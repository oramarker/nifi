package org.apache.nifi.update.attributes.servlet;

import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.server.VaadinServlet;
import org.apache.nifi.update.attributes.UI.TestUI;

import javax.servlet.ServletException;

//@VaadinServletConfiguration(productionMode = false, ui = TestUI.class)
public class TestServlet extends VaadinServlet {

    @Override
    protected final void servletInitialized() throws ServletException {
        super.servletInitialized();

        //getService().addSessionInitListener(new DashboardSessionInitListener());
    }
}
