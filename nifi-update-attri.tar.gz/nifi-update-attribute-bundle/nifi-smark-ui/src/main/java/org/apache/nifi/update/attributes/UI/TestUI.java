package org.apache.nifi.update.attributes.UI;

import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinServletRequest;
import com.vaadin.ui.*;
import org.apache.nifi.update.attributes.Criteria;
import org.apache.nifi.update.attributes.UI.view.LoginView;
import org.apache.nifi.update.attributes.serde.CriteriaSerDe;
import org.apache.nifi.web.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

@WebListener
public class TestUI extends UI  implements ServletContextListener {

    static ServletContext servletContext;
    private HttpServletRequest request;
    String processorId;

    @Override
    protected void init(VaadinRequest request) {

        final NiFiWebConfigurationContext nifiWebContext = (NiFiWebConfigurationContext) servletContext.getAttribute("nifi-web-configuration-context");

         processorId = request.getParameter("id");
        String clientId =request.getParameter("clientId");
        Long revisionId =Long.valueOf(request.getParameter("revision"));
        // Create the content root layout for the UI
        VerticalLayout content = new VerticalLayout();
        setContent(content);

        Label label = new Label("");

        // Display the greeting
        content.addComponent(label);


        TextField annoField = new TextField();
        content.addComponent(annoField);

        // Have a clickable button
        content.addComponent(new Button("Push Me!",
               click -> {
                   ComponentDetails processorDetail =  getProcessorDetail();

                   String annotationData = processorDetail.getAnnotationData();
                   String msg = "processorId="+ processorId + " clientId ="+ clientId + " annotation Data = "+ annotationData;
                   label.setValue(msg);
                Notification.show(msg);
        }
        ));

        content.addComponent(new Button("Save Annotation",
                click -> {
                    saveAnnotation(getConfigurationRequestContext(processorId,revisionId,clientId),annoField.getValue());
                    Notification.show("Saved");
                }
        ));

        //content.addComponent(new LoginView());
    }

    private NiFiWebConfigurationRequestContext getConfigurationRequestContext(final String processorId, final Long revision, final String clientId) {
        return new HttpServletConfigurationRequestContext(UiExtensionType.ProcessorConfiguration, request) {
            @Override
            public String getId() {
                return processorId;
            }

            @Override
            public Revision getRevision() {
                return new Revision(revision, clientId, processorId);
            }
        };
    }

    private void saveAnnotation(final NiFiWebConfigurationRequestContext requestContext, final String annotationData) {

        // get the web context
        final NiFiWebConfigurationContext configurationContext = (NiFiWebConfigurationContext) servletContext.getAttribute("nifi-web-configuration-context");

        try {
            // save the annotation data
            configurationContext.updateComponent(requestContext, annotationData, null);
        } catch (final InvalidRevisionException ire) {
            throw new WebApplicationException(ire, invalidRevision(ire.getMessage()));
        } catch (final Exception e) {
            final String message = String.format("Unable to save UpdateAttribute[id=%s] criteria: %s", requestContext.getId(), e);
            //logger.error(message, e);
            throw new WebApplicationException(e, error(message));
        }
    }

    private ComponentDetails getProcessorDetail(){

         ComponentDetails processorDetails = null;
        NiFiWebRequestContext requestContext=null;
        try {
            final NiFiWebConfigurationContext configurationContext = (NiFiWebConfigurationContext) servletContext.getAttribute("nifi-web-configuration-context");

             requestContext = getRequestContext(this.processorId);
            // load the processor configuration
            processorDetails = configurationContext.getComponentDetails(requestContext);
        } catch (final InvalidRevisionException ire) {
            throw new WebApplicationException(ire, invalidRevision(ire.getMessage()));
        } catch (final Exception e) {
            final String message = String.format("Unable to get UpdateAttribute[id=%s] criteria: %s", requestContext.getId(), e);
            //logger.error(message, e);
            throw new WebApplicationException(e, error(message));
        }
        return processorDetails;
    }

    private NiFiWebRequestContext getRequestContext(final String processorId) {

        VaadinServletRequest vsRequest = (VaadinServletRequest) VaadinService.getCurrentRequest ();
        HttpServletRequest httpServletRequest = vsRequest.getHttpServletRequest ();

        return new HttpServletRequestContext(UiExtensionType.ProcessorConfiguration, httpServletRequest) {
            @Override
            public String getId() {
                return processorId;
            }
        };
    }

    private Response invalidRevision(final String message) {
        return Response.status(Response.Status.CONFLICT).entity(message).type("text/plain").build();
    }

    private Response error(final String message) {
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(message).type("text/plain").build();
    }


    // Vaadin app deploying/launching.
    @Override
    public void contextInitialized ( ServletContextEvent contextEvent )
    {

        servletContext = contextEvent.getServletContext();

    }

    // Vaadin app un-deploying/shutting down.
    @Override
    public void contextDestroyed ( ServletContextEvent contextEvent )
    {
        //  ServletContext context = contextEvent.getServletContext();
        // …
    }
}
