package org.apache.nifi.controller.api.livy;

public class SparkExecutionException extends  Exception{

    public SparkExecutionException(String s, Throwable throwable) {
        super(s, throwable);
    }
}
