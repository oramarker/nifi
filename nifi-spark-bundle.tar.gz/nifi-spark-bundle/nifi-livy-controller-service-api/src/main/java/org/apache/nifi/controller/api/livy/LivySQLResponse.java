package org.apache.nifi.controller.api.livy;

import java.io.Serializable;
import java.util.List;

public class LivySQLResponse implements Serializable{

    private List<String> headers;
    private List<String> types;
    private List<String> data;

    public LivySQLResponse(List<String> headers, List<String> types, List<String> data) {
        this.headers = headers;
        this.types = types;
        this.data = data;
    }

    public List<String> getHeaders() {
        return headers;
    }

    public List<String> getTypes() {
        return types;
    }

    public List<String> getData() {
        return data;
    }
}
