package org.apache.nifi.controller.api.livy;

import java.io.Serializable;
import java.util.List;

public class LivySQLResponse implements Serializable{

    private List<String> headers;
    private List<String> types;
    private List<String> data;

}
