package org.apache.nifi.controller.api.livy;

import java.util.List;
import java.util.Map;

public interface EnhancedLivySessionService extends LivySessionService{

     Map<String, String> getSession(String sessionId);

    /**
     * Executes the spark sql and register the view as specified, it also returns the query result.
     * @param sqlViewRequest
     * @return An instance of LivySQLResponse
     */
    LivySQLResponse executeSQL(LivySQLViewRequest sqlViewRequest) throws SparkExecutionException,LivySessionNotAvailException;

    /**
     * Executes the spark sql and register the view as specified.
     * @param sqlViewRequest
     */
    void executeSQLView(LivySQLViewRequest sqlViewRequest)  throws SparkExecutionException,LivySessionNotAvailException;
}
