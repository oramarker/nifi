package org.apache.nifi.controller.api.livy;

import java.util.List;
import java.util.Map;

public interface EnhancedLivySessionService extends LivySessionService{

    //LivySession getLivySession(String clientId,String sessionId) throws LivySessionNotAvailException;

    LivySession createNewLivySession(String clientId) throws LivySessionNotAvailException;

    LivySession getLivySession(String clientId) throws LivySessionNotAvailException;

    void closeLivySession(String clientId) throws LivySessionNotAvailException;

    /**
     * Executes the spark sql and register the view as specified, it also returns the query result.
     * @param sqlViewRequest
     * @return An instance of LivySQLResponse
     */
   // LivySQLResponse executeSQL(LivySQLViewRequest sqlViewRequest) throws SparkExecutionException,LivySessionNotAvailException;

    /**
     * Executes the spark sql and register the view as specified.
     * @param sqlViewRequest
     */
   // void executeSQLView(LivySQLViewRequest sqlViewRequest)  throws SparkExecutionException,LivySessionNotAvailException;
}
