package org.apache.nifi.controller.api.livy;

import java.io.IOException;
import java.net.HttpURLConnection;

public interface IConnectionFactory {

    HttpURLConnection getConnection(String url) throws IOException;
}
