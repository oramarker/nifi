package org.apache.nifi.controller.api.livy;

public class LivySessionNotAvailException extends Exception {
    public LivySessionNotAvailException(String s) {
        super(s);
    }
}
