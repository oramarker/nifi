package org.apache.nifi.controller.api.livy;

import java.io.Serializable;

public class LivyRequest implements Serializable {
    private String clientId;
    private String sessionId;
    private String processorId;
    private int inquiryInterval = 1;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getProcessorId() {
        return processorId;
    }

    public void setProcessorId(String processorId) {
        this.processorId = processorId;
    }

    public int getInquiryInterval() {
        return inquiryInterval;
    }

    public void setInquiryInterval(int inquiryInterval) {
        this.inquiryInterval = inquiryInterval;
    }
}
