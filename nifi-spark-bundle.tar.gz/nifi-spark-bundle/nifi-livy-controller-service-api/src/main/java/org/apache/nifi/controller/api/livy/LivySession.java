package org.apache.nifi.controller.api.livy;

import java.io.Serializable;
import java.util.Date;

public class LivySession implements Serializable{
    private String clientId;
    private String sessionId;
    private Date createTime;
    private Date lastAcessTime;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLastAcessTime() {
        return lastAcessTime;
    }

    public void setLastAcessTime(Date lastAcessTime) {
        this.lastAcessTime = lastAcessTime;
    }
}
