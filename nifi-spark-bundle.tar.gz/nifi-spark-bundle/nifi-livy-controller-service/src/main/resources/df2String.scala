import org.json4s.DefaultFormats
import org.json4s.jackson.Serialization.write
import org.apache.spark.SparkContext
import org.apache.spark.sql.catalyst.expressions.Attribute
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
implicit val formats = DefaultFormats
case class SQLResult(header:Seq[String],data:Array[Seq[String]]);
def mapRow(row:Row,attrSeq:Seq[Attribute]):Seq[String]={
  val strList:Seq[String] = attrSeq.map(attr=>{
    val colValue = Option(row.getAs[Any](attr.name));
    colValue match{
      case None => "null"
      case Some(x) => x.toString
    }
  })
  strList
}
def getSQLResult(sql:String):String= {
  try {
    val df = spark.sql(sql);
    df.createOrReplaceTempView("$viewName")
    val attrList = df.queryExecution.analyzed.output;
    val rowArray = df.take($count);
    val listOfList = rowArray.map(mapRow(_, attrList))
    val result = SQLResult(attrList.map(attr => attr.name), listOfList)
    write(result)
  }catch {
    case ex: Exception => throw new RuntimeException(s"Failed to execute SQL:${ex.getMessage},$sql")
  }
  val sqlResult= getSQLResult($sql);
  println(s"<start>$sqlResult<end>")