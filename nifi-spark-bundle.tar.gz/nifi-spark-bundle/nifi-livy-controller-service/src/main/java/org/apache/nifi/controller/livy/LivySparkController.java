package org.apache.nifi.controller.livy;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.nifi.controller.api.livy.*;
import org.apache.nifi.logging.ComponentLog;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class LivySparkController extends LivySessionController implements EnhancedLivySessionService,IConnectionFactory{

    /* Livy session Map with key: clientId */
    private Map<String,LivySession> livySessionMap = new ConcurrentHashMap<>();


    private String getSessionState(String sessionId) throws LivySessionNotAvailException{
        JSONObject currentSession = sessions.get(sessionId);
        try {
            String state = currentSession.getString("state");
            String sessionKind = currentSession.getString("kind");
            return state;
           // if (state.equalsIgnoreCase("idle") && sessionKind.equalsIgnoreCase(controllerKind)) {
            //}
        }catch(JSONException ex){
            throw new LivySessionNotAvailException("Can not get session state."+ex.getMessage());
        }
    }
    private boolean isSessionIdle(String sessionId) throws LivySessionNotAvailException{
        return "idle".equalsIgnoreCase(getSessionState(sessionId));
    }
    private boolean isSessionBusy(String sessionId) throws LivySessionNotAvailException{
        return "busy".equalsIgnoreCase(getSessionState(sessionId));
    }
    private boolean isSessionStarting(String sessionId) throws LivySessionNotAvailException{
        return "starting".equalsIgnoreCase(getSessionState(sessionId));
    }
    private boolean isSessionValid(String sessionId)throws LivySessionNotAvailException{
        return ! (isSessionIdle(sessionId) || isSessionBusy(sessionId) || isSessionStarting(sessionId));
    }

    public LivySession createNewLivySession(String clientId) throws LivySessionNotAvailException{
        closeLivySession(clientId);
        Map<String,String> map = this.getSession();
        LivySession session = new LivySession();
        session.setClientId(clientId);
        session.setSessionId(map.get("sessionId"));
        session.setCreateTime(new Date());
        session.setLastAcessTime(new Date());
        livySessionMap.put(clientId,session);
        return session;
    }

    @Override
    public LivySession getLivySession(String clientId) throws LivySessionNotAvailException{
        LivySession session = livySessionMap.get(clientId);
        if(session == null){
            session = createNewLivySession(clientId);
        }

        String sessionId =  session.getSessionId();
       if( !isSessionIdle(sessionId)){
           throw new LivySessionNotAvailException("Session is busy now:"+sessionId);
        }
        return session;
    }

    public void closeLivySession(String clientId) throws LivySessionNotAvailException{
        LivySession session = livySessionMap.get(clientId);
        if(session !=null){
            livySessionMap.remove(clientId);
            try {
                deleteSession(session.getSessionId());
            }catch(IOException ex){
                throw new LivySessionNotAvailException("Unable to close existing active session with this clientId");
            }

        }
    }


   /* @Override
    public LivySession getLivySession(String clientId,String sessionId) throws LivySessionNotAvailException {

        Map<String, String> sessionMap = new HashMap<>();
        try {
            final Map<Integer, JSONObject> sessionsCopy = sessions;
            JSONObject currentSession = sessions.get(sessionId);
            if(currentSession != null) {
                String state = currentSession.getString("state");
                String sessionKind = currentSession.getString("kind");
                if (state.equalsIgnoreCase("idle") && sessionKind.equalsIgnoreCase(controllerKind)) {
                    sessionMap.put("sessionId", String.valueOf(sessionId));
                    sessionMap.put("livyUrl", livyUrl);
                }
            }
        } catch (JSONException e) {
            getLogger().error("Unexpected data found when looking for JSON object with 'state' and 'kind' fields", e);
        }
        return sessionMap;
    }*/
    private JSONObject executeCode(String clientId,String code,int statusCheckInterval) throws SparkExecutionException,LivySessionNotAvailException{
        LivySession session = this.getLivySession(clientId);
        String sessionId = session.getSessionId();

        code = StringEscapeUtils.escapeEcmaScript(code);
        String payload = "{\"code\":\"" + code + "\"}";
        try {
            final JSONObject result = submitAndHandleJob(livyUrl, this, sessionId, payload, statusCheckInterval);
            getLogger().debug("ExecuteSparkInteractive Result of Job Submit: " + result);
            if (result != null) {
                final JSONObject output = result.getJSONObject("data");
                return output;
            }
            return null;
        } catch (Exception joe) {
            throw new SparkExecutionException("Error when executing spark code:"+joe.getMessage(),joe);
        }
    }

    private JSONObject submitAndHandleJob(String livyUrl, LivySessionService livySessionService, String sessionId, String payload, long statusCheckInterval) throws IOException {
        ComponentLog log = getLogger();
        String statementUrl = livyUrl + "/sessions/" + sessionId + "/statements";
        JSONObject output = null;
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", LivySessionService.APPLICATION_JSON);
        headers.put("X-Requested-By", LivySessionService.USER);
        headers.put("Accept", "application/json");

        log.debug("submitAndHandleJob() Submitting Job to Spark via: " + statementUrl);
        try {
            JSONObject jobInfo = readJSONObjectFromUrlPOST(statementUrl, livySessionService, headers, payload);
            log.debug("submitAndHandleJob() Job Info: " + jobInfo);
            String statementId = String.valueOf(jobInfo.getInt("id"));
            statementUrl = statementUrl + "/" + statementId;
            jobInfo = readJSONObjectFromUrl(statementUrl, livySessionService, headers);
            String jobState = jobInfo.getString("state");

            log.debug("submitAndHandleJob() New Job Info: " + jobInfo);
            Thread.sleep(statusCheckInterval);
            if (jobState.equalsIgnoreCase("available")) {
                log.debug("submitAndHandleJob() Job status is: " + jobState + ". returning output...");
                output = jobInfo.getJSONObject("output");
            } else if (jobState.equalsIgnoreCase("running") || jobState.equalsIgnoreCase("waiting")) {
                while (!jobState.equalsIgnoreCase("available")) {
                    log.debug("submitAndHandleJob() Job status is: " + jobState + ". Waiting for job to complete...");
                    Thread.sleep(statusCheckInterval);
                    jobInfo = readJSONObjectFromUrl(statementUrl, livySessionService, headers);
                    jobState = jobInfo.getString("state");
                }
                output = jobInfo.getJSONObject("output");
            } else if (jobState.equalsIgnoreCase("error")
                    || jobState.equalsIgnoreCase("cancelled")
                    || jobState.equalsIgnoreCase("cancelling")) {
                log.debug("Job status is: " + jobState + ". Job did not complete due to error or has been cancelled. Check SparkUI for details.");
                throw new IOException(jobState);
            }
        } catch (JSONException | InterruptedException e) {
            throw new IOException(e);
        }
        return output;
    }

    private JSONObject readJSONObjectFromUrlPOST(String urlString, LivySessionService livySessionService, Map<String, String> headers, String payload)
            throws IOException, JSONException {

        HttpURLConnection connection = livySessionService.getConnection(urlString);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);

        for (Map.Entry<String, String> entry : headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }

        OutputStream os = connection.getOutputStream();
        os.write(payload.getBytes());
        os.flush();

        if (connection.getResponseCode() != HttpURLConnection.HTTP_OK && connection.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
            throw new RuntimeException("Failed : HTTP error code : " + connection.getResponseCode() + " : " + connection.getResponseMessage());
        }

        InputStream content = connection.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(content, StandardCharsets.UTF_8));
        String jsonText = IOUtils.toString(rd);
        return new JSONObject(jsonText);
    }

    private JSONObject readJSONObjectFromUrl(final String urlString, LivySessionService livySessionService, final Map<String, String> headers)
            throws IOException, JSONException {

        HttpURLConnection connection = livySessionService.getConnection(urlString);
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }
        connection.setRequestMethod("GET");
        connection.setDoOutput(true);
        InputStream content = connection.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(content, StandardCharsets.UTF_8));
        String jsonText = IOUtils.toString(rd);
        return new JSONObject(jsonText);
    }
}
