package org.apache.nifi.controller.livy;

public class LivySessionKey {
    private String clientId;
    private String sessionId;

    public LivySessionKey(String clientId, String sessionId) {
        this.clientId = clientId;
        this.sessionId = sessionId;
    }

    public String getClientId() {
        return clientId;
    }

    public String getSessionId() {
        return sessionId;
    }
}
