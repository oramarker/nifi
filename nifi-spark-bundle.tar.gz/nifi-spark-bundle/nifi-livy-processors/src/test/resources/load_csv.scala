val fileName = "/Users/zrq/workspace/vaddin/smark-core/src/test/resources/cars.csv"
val df = spark.read.format("csv").option("header", "true").option("mode", "DROPMALFORMED").load(fileName)
df.createOrReplaceTempView("cars")