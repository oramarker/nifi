package org.apache.nifi.processors.livy;

import org.apache.commons.io.IOUtils;
import org.codehaus.jettison.json.JSONObject;
import org.junit.Test;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class TestLivyManager {

    @Test
    public void testLivySQL() throws Exception{

        String loadCSV = loadCode("load_csv.scala");
        LivyManager m = new LivyManager();
        m.setConnectionFactory(new SimpleConnectionFactory());
        String livyUrl = "http://localhost:8998";
        JSONObject jsonObject = m.openSession(livyUrl);
        int sessionId= jsonObject.getInt("id");


        String carsSQL = "select * from cars";
        JSONObject loadCSVResult = m.executeCode(livyUrl, String.valueOf(sessionId), loadCSV, LivyManager.SPARK_SESSION_SPARK, 1);
        JSONObject sqlReslt = m.executeCode(livyUrl, String.valueOf(sessionId), carsSQL, LivyManager.SPARK_SESSION_SQL, 1);

    }

    private String loadCode(String fileName) throws Exception{
        InputStream in = this.getClass().getResourceAsStream("/"+fileName);
        String text = IOUtils.toString(in, StandardCharsets.UTF_8);
        in.close();
        return text;


    }
}
