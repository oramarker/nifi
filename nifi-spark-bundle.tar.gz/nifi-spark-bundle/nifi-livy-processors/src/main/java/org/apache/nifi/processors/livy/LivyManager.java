package org.apache.nifi.processors.livy;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.nifi.controller.api.livy.*;
import org.apache.nifi.logging.ComponentLog;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class LivyManager {

    static String APPLICATION_JSON = "application/json";
    static String USER = "nifi";
    static final String SPARK_SESSION_SPARK="spark";
    static final String SPARK_SESSION_PYSPARK="pyspark";
    static final String SPARK_SESSION_SPARKR="sparkr";
    static final String SPARK_SESSION_SQL="sql";

    private IConnectionFactory connectionFactory;


    private EnhancedLivySessionService livySessionService;
    private  ComponentLog log;

    public void setLivySessionService(EnhancedLivySessionService livySessionService) {
        this.livySessionService = livySessionService;
    }

    private  void logDebug(Object obj){
        if(log==null){
            System.out.println(obj);
        }else{
            logDebug(obj.toString());
        }
    }

    public  void setConnectionFactory(IConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }

    public JSONObject executeCode(String livyUrl, String sessionId, String code, String codeKind,int statusCheckInterval) throws SparkExecutionException,LivySessionNotAvailException {


        code = StringEscapeUtils.escapeEcmaScript(code);
        StringBuilder b = new StringBuilder();
        b.append("{");
        b.append("\"code\":\"" + code + "\"");
        b.append(",\"kind\":\"" + codeKind + "\"");

        b.append("}");
        String payload = b.toString();
        logDebug("payLoad:"+payload);
        try {
            final JSONObject result = submitAndHandleJob(livyUrl,  sessionId, payload, statusCheckInterval);
           logDebug("ExecuteSparkInteractive Result of Job Submit: " + result);
            if (result != null) {
                final JSONObject output = result.getJSONObject("data");
                return output;
            }
            return null;
        } catch (Exception joe) {
            throw new SparkExecutionException("Error when executing spark code:"+joe.getMessage(),joe);
        }
    }

    public JSONObject openSession(String livyUrl) throws IOException, JSONException, InterruptedException {
       // ComponentLog log = getLogger();
        JSONObject newSessionInfo;
       // final ObjectMapper mapper = new ObjectMapper();

        String sessionsUrl = livyUrl + "/sessions";
        StringBuilder payload = new StringBuilder("{");


        payload.append("}");

        logDebug("openSession() Session Payload: " + payload.toString());
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", APPLICATION_JSON);
        headers.put("X-Requested-By", USER);

        newSessionInfo = readJSONObjectFromUrlPOST(sessionsUrl, headers, payload.toString());
        Thread.sleep(1000);
        while (newSessionInfo.getString("state").equalsIgnoreCase("starting")) {
            logDebug("openSession() Waiting for session to start...");
            newSessionInfo = getSessionInfo(livyUrl,newSessionInfo.getInt("id"));
            logDebug("openSession() newSessionInfo: " + newSessionInfo);
            Thread.sleep(1000);
        }

        return newSessionInfo;
    }

    public   JSONObject submitAndHandleJob(String livyUrl, String sessionId, String payload, long statusCheckInterval) throws IOException {
    //    ComponentLog log = getLogger();
        String statementUrl = livyUrl + "/sessions/" + sessionId + "/statements";
        JSONObject output = null;
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", LivySessionService.APPLICATION_JSON);
        headers.put("X-Requested-By", LivySessionService.USER);
        headers.put("Accept", "application/json");

        logDebug("submitAndHandleJob() Submitting Job to Spark via: " + statementUrl);
        try {
            JSONObject jobInfo = readJSONObjectFromUrlPOST(statementUrl, headers, payload);
            logDebug("submitAndHandleJob() Job Info: " + jobInfo);
            String statementId = String.valueOf(jobInfo.getInt("id"));
            statementUrl = statementUrl + "/" + statementId;
            jobInfo = readJSONObjectFromUrl(statementUrl, headers);
            String jobState = jobInfo.getString("state");

            logDebug("submitAndHandleJob() New Job Info: " + jobInfo);
            Thread.sleep(statusCheckInterval);
            if (jobState.equalsIgnoreCase("available")) {
                logDebug("submitAndHandleJob() Job status is: " + jobState + ". returning output...");
                output = jobInfo.getJSONObject("output");
            } else if (jobState.equalsIgnoreCase("running") || jobState.equalsIgnoreCase("waiting")) {
                while (!jobState.equalsIgnoreCase("available")) {
                    logDebug("submitAndHandleJob() Job status is: " + jobState + ". Waiting for job to complete...");
                    Thread.sleep(statusCheckInterval);
                    jobInfo = readJSONObjectFromUrl(statementUrl, headers);
                    jobState = jobInfo.getString("state");
                }
                output = jobInfo.getJSONObject("output");
            } else if (jobState.equalsIgnoreCase("error")
                    || jobState.equalsIgnoreCase("cancelled")
                    || jobState.equalsIgnoreCase("cancelling")) {
                logDebug("Job status is: " + jobState + ". Job did not complete due to error or has been cancelled. Check SparkUI for details.");
                throw new IOException(jobState);
            }
        } catch (JSONException | InterruptedException e) {
            throw new IOException(e);
        }
        return output;
    }


    public   JSONObject readJSONObjectFromUrlPOST(String urlString, Map<String, String> headers, String payload)
            throws IOException, JSONException {

        HttpURLConnection connection = getConnection(urlString);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);

        for (Map.Entry<String, String> entry : headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }

        OutputStream os = connection.getOutputStream();
        os.write(payload.getBytes());
        os.flush();

        if (connection.getResponseCode() != HttpURLConnection.HTTP_OK && connection.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
            throw new RuntimeException("Failed : HTTP error code : " + connection.getResponseCode() + " : " + connection.getResponseMessage());
        }

        InputStream content = connection.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(content, StandardCharsets.UTF_8));
        String jsonText = IOUtils.toString(rd);
        return new JSONObject(jsonText);
    }

    public   JSONObject readJSONObjectFromUrl(final String urlString, final Map<String, String> headers)
            throws IOException, JSONException {

        HttpURLConnection connection = getConnection(urlString);
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }
        connection.setRequestMethod("GET");
        connection.setDoOutput(true);
        InputStream content = connection.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(content, StandardCharsets.UTF_8));
        String jsonText = IOUtils.toString(rd);
        return new JSONObject(jsonText);
    }

    private JSONObject getSessionInfo(String livyUrl,int sessionId) throws IOException {
        String sessionUrl = livyUrl + "/sessions/" + sessionId;
        JSONObject sessionInfo;
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", APPLICATION_JSON);
        headers.put("X-Requested-By", USER);
        try {
            sessionInfo = readJSONFromUrl(sessionUrl, headers,"GET");
        } catch (JSONException e) {
            throw new IOException(e);
        }

        return sessionInfo;
    }

    private JSONObject readJSONFromUrl(String urlString, Map<String, String> headers,String method) throws IOException, JSONException {

        HttpURLConnection connection = getConnection(urlString);
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }
        connection.setRequestMethod(method);
        if(method == "GET") {
            connection.setDoOutput(true);
            InputStream content = connection.getInputStream();
            return readAllIntoJSONObject(content);
        }else{
            return null;
        }
    }

    private JSONObject readAllIntoJSONObject(InputStream content) throws IOException, JSONException {
        BufferedReader rd = new BufferedReader(new InputStreamReader(content, StandardCharsets.UTF_8));
        String jsonText = IOUtils.toString(rd);
        return new JSONObject(jsonText);
    }

    private HttpURLConnection getConnection(String urlString) throws IOException{
        if(this.livySessionService!=null){
           return livySessionService.getConnection(urlString);
        }else if(this.connectionFactory!=null){
           return  this.connectionFactory.getConnection(urlString);
        }else{
            throw new RuntimeException("No connection factory is provided.");
        }
    }
}
