/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.nifi.processors.livy;

import org.apache.nifi.annotation.behavior.InputRequirement;
import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.annotation.documentation.Tags;
import org.apache.nifi.components.PropertyDescriptor;
import org.apache.nifi.controller.api.livy.EnhancedLivySessionService;
import org.apache.nifi.controller.api.livy.IConnectionFactory;
import org.apache.nifi.controller.api.livy.LivySession;
import org.apache.nifi.controller.api.livy.LivySessionNotAvailException;
import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.logging.ComponentLog;
import org.apache.nifi.processor.*;
import org.apache.nifi.processor.exception.ProcessException;
import org.apache.nifi.processor.util.StandardValidators;

import java.util.*;

@InputRequirement(InputRequirement.Requirement.INPUT_REQUIRED)
@Tags({"spark", "livy", "http", "execute"})
@CapabilityDescription("Executes SQL and register a view")
public class SparkExecSQL extends AbstractProcessor {

    public static final PropertyDescriptor LIVY_CONTROLLER_SERVICE = new PropertyDescriptor.Builder()
            .name("exec-spark-iactive-livy-controller-service")
            .displayName("Enhanced Livy Controller Service")
            .description("The controller service to use for Livy-managed session(s).")
            .required(true)
            .identifiesControllerService(EnhancedLivySessionService.class)
            .build();

    public static final PropertyDescriptor SQL = new PropertyDescriptor.Builder()
            .name("spark-sql")
            .displayName("Spark SQL")
            .description("A Spark SQL statement ")
            .required(true)
            .addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
            .expressionLanguageSupported(true)
            .build();

    public static final PropertyDescriptor VIEW_NAME = new PropertyDescriptor.Builder()
            .name("spark-view")
            .displayName("Spark View")
            .description("Spark temporary view name ")
            .required(true)
            .addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
            .expressionLanguageSupported(true)
            .build();
    public static final Relationship REL_SUCCESS = new Relationship.Builder()
            .name("success")
            .description("FlowFiles that are successfully processed are sent to this relationship")
            .build();

    public static final Relationship REL_FAILURE = new Relationship.Builder()
            .name("failure")
            .description("FlowFiles are routed to this relationship when they cannot be parsed")
            .build();

    private volatile List<PropertyDescriptor> properties;
    private volatile Set<Relationship> relationships;

    @Override
    public void init(final ProcessorInitializationContext context) {
        List<PropertyDescriptor> properties = new ArrayList<>();
        properties.add(LIVY_CONTROLLER_SERVICE);
        properties.add(SQL);
        properties.add(VIEW_NAME);
        this.properties = Collections.unmodifiableList(properties);

        Set<Relationship> relationships = new HashSet<>();
        relationships.add(REL_SUCCESS);
        //relationships.add(REL_WAIT);
        relationships.add(REL_FAILURE);
        this.relationships = Collections.unmodifiableSet(relationships);
    }

    @Override
    public Set<Relationship> getRelationships() {
        return relationships;
    }

    @Override
    protected List<PropertyDescriptor> getSupportedPropertyDescriptors() {
        return properties;
    }

    @Override
    public void onTrigger(ProcessContext context, final ProcessSession session) throws ProcessException {

        FlowFile flowFile = session.get();
        if (flowFile == null) {
            return;
        }

        final ComponentLog log = getLogger();
        String sparkJobId = context.getProperty("spark.job.id").evaluateAttributeExpressions(flowFile).getValue();
        final EnhancedLivySessionService livySessionService = context.getProperty(LIVY_CONTROLLER_SERVICE).asControllerService(EnhancedLivySessionService.class);

        LivySession livySession = null;
        try {
            livySession = livySessionService.getLivySession(sparkJobId);
            LivyManager manager = new LivyManager();
            manager.setLivySessionService(livySessionService);

            //manager.executeCode(livySession.)

            flowFile = session.putAttribute(flowFile, "spark.job.id", sparkJobId);
            flowFile = session.putAttribute(flowFile, "spark.session.id", livySession.getSessionId());
            session.transfer(flowFile, REL_SUCCESS);
        }catch(LivySessionNotAvailException ex){
            log.debug("No Spark session available (yet), routing flowfile to wait");
            flowFile = session.penalize(flowFile);
            session.transfer(flowFile, REL_FAILURE);

        }

    }


}
