package org.apache.nifi.processors.livy;

import org.apache.nifi.controller.api.livy.IConnectionFactory;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class SimpleConnectionFactory implements IConnectionFactory {
    @Override
    public HttpURLConnection getConnection(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(10);
        //HttpURLConnection connection = getConnection(urlString);
        return connection;
    }
}
